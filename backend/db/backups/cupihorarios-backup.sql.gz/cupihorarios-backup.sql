--
-- PostgreSQL database dump
--

-- Dumped from database version 15.7 (Homebrew)
-- Dumped by pg_dump version 15.7 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: unaccent; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS unaccent WITH SCHEMA public;


--
-- Name: EXTENSION unaccent; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION unaccent IS 'text search dictionary that removes accents';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: day; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.day AS ENUM (
    'MONDAY',
    'TUESDAY',
    'WEDNESDAY',
    'THURSDAY',
    'FRIDAY',
    'SATURDAY',
    'SUNDAY'
);


ALTER TYPE public.day OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: assistant_availabilities; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.assistant_availabilities (
    id uuid NOT NULL,
    assistant_code integer NOT NULL,
    time_slot_id uuid NOT NULL,
    virtual_only boolean NOT NULL
);


ALTER TABLE public.assistant_availabilities OWNER TO postgres;

--
-- Name: assistants; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.assistants (
    code integer NOT NULL,
    login character varying NOT NULL,
    first_names character varying NOT NULL,
    last_names character varying NOT NULL,
    nickname character varying
);


ALTER TABLE public.assistants OWNER TO postgres;

--
-- Name: assistants_code_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.assistants_code_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.assistants_code_seq OWNER TO postgres;

--
-- Name: assistants_code_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.assistants_code_seq OWNED BY public.assistants.code;


--
-- Name: scheduled_slots; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.scheduled_slots (
    schedule_id uuid NOT NULL,
    assistant_availability_id uuid NOT NULL,
    is_virtual boolean NOT NULL
);


ALTER TABLE public.scheduled_slots OWNER TO postgres;

--
-- Name: schedules; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.schedules (
    id uuid NOT NULL,
    name character varying NOT NULL,
    is_official boolean NOT NULL
);


ALTER TABLE public.schedules OWNER TO postgres;

--
-- Name: time_slots; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.time_slots (
    id uuid NOT NULL,
    start_hour integer NOT NULL,
    end_hour integer NOT NULL,
    day public.day NOT NULL
);


ALTER TABLE public.time_slots OWNER TO postgres;

--
-- Name: assistants code; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.assistants ALTER COLUMN code SET DEFAULT nextval('public.assistants_code_seq'::regclass);


--
-- Data for Name: assistant_availabilities; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.assistant_availabilities (id, assistant_code, time_slot_id, virtual_only) FROM stdin;
\.


--
-- Data for Name: assistants; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.assistants (code, login, first_names, last_names, nickname) FROM stdin;
194821525	m.laserna	Mario Alberto	Laserna Pinzón	Maritoooo
\.


--
-- Data for Name: scheduled_slots; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.scheduled_slots (schedule_id, assistant_availability_id, is_virtual) FROM stdin;
\.


--
-- Data for Name: schedules; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.schedules (id, name, is_official) FROM stdin;
\.


--
-- Data for Name: time_slots; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.time_slots (id, start_hour, end_hour, day) FROM stdin;
b3bb189e-8bf9-3888-9912-ace4e6543002	1000	1200	TUESDAY
dfcb30ae-1e73-4ae8-a44e-dbc184356321	800	900	MONDAY
07ef1fb2-31f5-4524-be33-f9d43c13f51e	900	930	MONDAY
e0743d9f-1d05-4034-bdaa-56778e4652d2	930	1030	MONDAY
7961c95e-bd2f-4ca2-a142-9890390aaf11	1030	1100	MONDAY
81c1c6f8-ec54-4940-ac2f-feb300167844	1100	1200	MONDAY
349f1327-4a70-42c9-bdbf-3d70e72c567f	1200	1230	MONDAY
d764a1cc-1dda-4acb-8184-c9067f028ab0	1230	1330	MONDAY
35973de7-1c5b-4c69-ad86-bcc69800772d	1330	1400	MONDAY
c9abc047-73cf-4c5b-80eb-a9cdcfaeeba1	1400	1500	MONDAY
262cdcd3-f553-420a-83a0-44c477da5767	1500	1530	MONDAY
650ac6cd-33ba-4ac1-8438-00c66b0e70d2	1530	1630	MONDAY
d63cf187-b7ce-440d-9acf-655df65ce99c	1630	1700	MONDAY
c85319b8-641d-4e34-869a-d67370a71c2f	1700	1800	MONDAY
19099e5b-4e36-436e-9e58-5bf62c9a5a04	800	900	TUESDAY
f3c649ca-7c17-42f0-9ff8-570a95752f6a	900	930	TUESDAY
f12bb66d-c26e-4f4c-9dd9-b5ef803bfbed	930	1030	TUESDAY
8e1e2f50-8094-44cd-bdda-8cbe67a52961	1030	1100	TUESDAY
ac260ddc-5bab-4645-b52d-e7e683d082bd	1100	1200	TUESDAY
db9bdf90-9768-4bab-83b6-27399facb121	1200	1230	TUESDAY
cdd857bc-6a12-4922-873d-279fa1aea64c	1230	1330	TUESDAY
cefb686a-ce96-4b97-b952-688b708e55aa	1330	1400	TUESDAY
eba8ef35-b00d-4146-9eb4-83006a686289	1400	1500	TUESDAY
a9317de6-eeeb-487a-b31a-15ca025cf786	1500	1530	TUESDAY
6cbc71f7-b9ab-4c06-bfc8-4777a873a4da	1530	1630	TUESDAY
cfb61b04-62fc-4a30-9fa1-90bfa168e335	1630	1700	TUESDAY
8ea496a8-0557-4c9f-8ba8-2bc3019eaebb	1700	1800	TUESDAY
c128c9a6-9c0d-4b10-8c1d-90db09f0a8ad	800	900	WEDNESDAY
c0d280e9-1904-4495-8298-a4d84932470e	900	930	WEDNESDAY
d80e29e1-3dec-4f01-9a9a-d19924b10f9e	930	1030	WEDNESDAY
a5e306c0-9bea-4bce-92f3-c86fe056f10a	1030	1100	WEDNESDAY
a58b0142-c8df-42b0-b018-eb53531cdb6b	1100	1200	WEDNESDAY
243beda9-8549-4b7e-bfb5-8a3291e1c2ef	1200	1230	WEDNESDAY
18622b0f-7524-4caa-b24b-fdde53391857	1230	1330	WEDNESDAY
c3bc9137-aaf1-467c-9de8-3adbac5f8121	1330	1400	WEDNESDAY
8f2f7527-73fd-45d6-ba87-26c3147eb0bc	1400	1500	WEDNESDAY
4a2d6be2-3864-402b-92a0-92b26a78944f	1500	1530	WEDNESDAY
81869a2a-e81e-4160-a5c2-b428bee022b5	1530	1630	WEDNESDAY
a89edceb-724f-4931-9ab4-2604698f3c47	1630	1700	WEDNESDAY
8a80ac95-dee4-4a98-abc7-222d9b3c9e67	1700	1800	WEDNESDAY
730e8ac1-44e6-4e0f-88bb-2c9ff0b588c6	800	900	THURSDAY
041a895a-9f51-40d1-ab07-9743a342b4d3	900	930	THURSDAY
819d37b1-6210-404c-87ad-c746c81b208d	930	1030	THURSDAY
bf801247-26f2-4b35-a917-f58bb8c16492	1030	1100	THURSDAY
62a4becd-7219-44ce-8a93-d3122a93fabf	1100	1200	THURSDAY
8383e7ec-e7da-4f82-a212-b426a5664ba2	1200	1230	THURSDAY
05de2768-f767-438e-87fd-95503974ee63	1230	1330	THURSDAY
b0ba0ee2-f93e-4940-b855-6cc02d9fa02b	1330	1400	THURSDAY
a272e1e4-ce24-4d93-aef2-06798f7771b3	1400	1500	THURSDAY
8f0edafc-87ec-41cf-9004-2f83f1124a02	1500	1530	THURSDAY
9cd7624e-ceb8-480a-99c9-ea800fbbef43	1530	1630	THURSDAY
faa0773a-a943-4de2-9d1c-ac4f2171c826	1630	1700	THURSDAY
3b4a1d11-b299-488b-991a-060108f47d9c	1700	1800	THURSDAY
19f8689c-445d-44aa-9b90-2765dd1fd88e	800	900	FRIDAY
00be3f12-b0c0-4a31-af02-388bf6ab4ba5	900	930	FRIDAY
8ecc2733-0830-4a37-b1c7-1cd88ea2fbb4	930	1030	FRIDAY
f0ef3df4-4fff-40f9-9c87-78a41423554b	1030	1100	FRIDAY
2340671a-bc40-40af-ab6c-91e55c4f040c	1100	1200	FRIDAY
c441633d-7670-4fb8-b6bb-fc1e97d283ee	1200	1230	FRIDAY
6ff933ad-4d72-481d-b40d-1b87f65fbfd8	1230	1330	FRIDAY
0d5f8bc9-02af-4cf9-9efc-7181ac1649b6	1330	1400	FRIDAY
d820daa5-04b6-4ddd-92ef-1979dbfcefcd	1400	1500	FRIDAY
a7fd0f5a-28a3-4f2d-bdab-055d76e6103c	1500	1530	FRIDAY
9f40855b-372e-4a45-9d5a-728ab68d76c2	1530	1630	FRIDAY
560d3bfb-26b3-4318-a3f9-a323fa264389	1630	1700	FRIDAY
bd179b92-368f-4b7b-81dd-5afcb2934d3e	1700	1800	FRIDAY
f35b7b55-350a-4d27-81c0-d28f3e235f39	800	900	SATURDAY
880220e0-dc5c-43d3-b3ec-4cba4db96751	900	930	SATURDAY
db7696d9-32fa-4f83-bd9f-023028b9806f	930	1030	SATURDAY
37e23be6-43bd-49c8-908e-9d9616c31508	1030	1100	SATURDAY
1d360e19-0859-47fb-8aa7-ffbb1f733516	1100	1200	SATURDAY
ccb985aa-496c-4f9e-b679-05cb2fd80db7	1200	1230	SATURDAY
58ab8e7d-bd73-400a-bf00-3b6fc8a205e2	1230	1330	SATURDAY
6117c86a-86e2-4093-aaa9-bd194d7019d2	1330	1400	SATURDAY
3305a05c-2f1b-4e52-b5f6-cdb33e733fa1	1400	1500	SATURDAY
77485354-c397-4b03-b857-abddbeb7a874	1500	1530	SATURDAY
bb42b855-10b0-4291-9d3e-40ed2d04937b	1530	1630	SATURDAY
b50dac26-2cf7-4387-a4bf-28fddcd17425	1630	1700	SATURDAY
e6098e0f-5ecd-448f-96a8-b158491584ef	1700	1800	SATURDAY
2b8f893c-02c9-4141-b32e-8f912ff8acd3	800	900	SUNDAY
ef244be8-9895-434b-b18a-0ac668da28b1	900	930	SUNDAY
dda3d1c7-2509-4a82-b635-766dedcb9fe4	930	1030	SUNDAY
dc370f68-267e-4d77-bd2f-a456f5d7ae82	1030	1100	SUNDAY
cafa37ef-a4e6-493b-8012-8199c0cd4898	1100	1200	SUNDAY
9055d6ba-3493-4d4a-9403-9e19290d3fa7	1200	1230	SUNDAY
5991bce9-730a-49c5-917f-ebf78970d398	1230	1330	SUNDAY
5028ef43-481a-4fc4-86ef-9652963dc616	1330	1400	SUNDAY
4bcbd9fd-e201-49fd-aa02-9f8544c63a07	1400	1500	SUNDAY
ca0e8c03-8789-417b-bf2d-fd9046eb3b6d	1500	1530	SUNDAY
64f3c8a6-31da-4d31-a055-3b9bab43cbef	1530	1630	SUNDAY
4c66419d-4d79-4c4c-9425-5cd077ba8151	1630	1700	SUNDAY
80a5f6ce-6a7e-4964-8795-8d930d02784e	1700	1800	SUNDAY
\.


--
-- Name: assistants_code_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.assistants_code_seq', 1, false);


--
-- Name: assistant_availabilities assistant_availabilities_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.assistant_availabilities
    ADD CONSTRAINT assistant_availabilities_pkey PRIMARY KEY (id);


--
-- Name: assistants assistants_login_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.assistants
    ADD CONSTRAINT assistants_login_key UNIQUE (login);


--
-- Name: assistants assistants_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.assistants
    ADD CONSTRAINT assistants_pkey PRIMARY KEY (code);


--
-- Name: scheduled_slots scheduled_slots_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.scheduled_slots
    ADD CONSTRAINT scheduled_slots_pkey PRIMARY KEY (schedule_id, assistant_availability_id);


--
-- Name: schedules schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedules
    ADD CONSTRAINT schedules_pkey PRIMARY KEY (id);


--
-- Name: time_slots time_slots_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.time_slots
    ADD CONSTRAINT time_slots_pkey PRIMARY KEY (id);


--
-- Name: assistant_availabilities assistant_availabilities_assistant_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.assistant_availabilities
    ADD CONSTRAINT assistant_availabilities_assistant_code_fkey FOREIGN KEY (assistant_code) REFERENCES public.assistants(code);


--
-- Name: assistant_availabilities assistant_availabilities_time_slot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.assistant_availabilities
    ADD CONSTRAINT assistant_availabilities_time_slot_id_fkey FOREIGN KEY (time_slot_id) REFERENCES public.time_slots(id);


--
-- Name: scheduled_slots scheduled_slots_assistant_availability_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.scheduled_slots
    ADD CONSTRAINT scheduled_slots_assistant_availability_id_fkey FOREIGN KEY (assistant_availability_id) REFERENCES public.assistant_availabilities(id);


--
-- Name: scheduled_slots scheduled_slots_schedule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.scheduled_slots
    ADD CONSTRAINT scheduled_slots_schedule_id_fkey FOREIGN KEY (schedule_id) REFERENCES public.schedules(id);


--
-- PostgreSQL database dump complete
--

