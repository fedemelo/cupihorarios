--
-- PostgreSQL database dump
--

-- Dumped from database version 15.7 (Homebrew)
-- Dumped by pg_dump version 15.7 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: unaccent; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS unaccent WITH SCHEMA public;


--
-- Name: EXTENSION unaccent; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION unaccent IS 'text search dictionary that removes accents';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: day; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.day AS ENUM (
    'MONDAY',
    'TUESDAY',
    'WEDNESDAY',
    'THURSDAY',
    'FRIDAY',
    'SATURDAY',
    'SUNDAY'
);


ALTER TYPE public.day OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: assistant_availabilities; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.assistant_availabilities (
    id uuid NOT NULL,
    assistant_code integer NOT NULL,
    time_slot_id uuid NOT NULL,
    remote_only boolean NOT NULL
);


ALTER TABLE public.assistant_availabilities OWNER TO postgres;

--
-- Name: assistants; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.assistants (
    code integer NOT NULL,
    login character varying NOT NULL,
    first_names character varying NOT NULL,
    last_names character varying NOT NULL,
    nickname character varying
);


ALTER TABLE public.assistants OWNER TO postgres;

--
-- Name: assistants_code_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.assistants_code_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.assistants_code_seq OWNER TO postgres;

--
-- Name: assistants_code_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.assistants_code_seq OWNED BY public.assistants.code;


--
-- Name: scheduled_slots; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.scheduled_slots (
    schedule_id uuid NOT NULL,
    assistant_availability_id uuid NOT NULL,
    is_remote boolean NOT NULL
);


ALTER TABLE public.scheduled_slots OWNER TO postgres;

--
-- Name: schedules; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.schedules (
    id uuid NOT NULL,
    name character varying NOT NULL,
    is_official boolean NOT NULL
);


ALTER TABLE public.schedules OWNER TO postgres;

--
-- Name: time_slots; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.time_slots (
    id uuid NOT NULL,
    start_hour integer NOT NULL,
    end_hour integer NOT NULL,
    day public.day NOT NULL
);


ALTER TABLE public.time_slots OWNER TO postgres;

--
-- Name: assistants code; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.assistants ALTER COLUMN code SET DEFAULT nextval('public.assistants_code_seq'::regclass);


--
-- Data for Name: assistant_availabilities; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.assistant_availabilities (id, assistant_code, time_slot_id, remote_only) FROM stdin;
3e011cc2-f247-4927-8d4d-d554a9e87b32	201913554	cc8840e4-0a7a-467f-a0f9-5392cbf2e78d	f
48e7511e-650c-409a-bbf7-9429429d3c6e	201913554	95a27c59-b9b7-49be-943e-3e47ba5a0810	f
2b544955-ab68-4d1c-8697-afb2f67a1e13	201913554	9d943ab7-f942-47eb-a5d9-7db4d137e0e3	f
073dcbf0-b883-474c-95e4-44dff76956d5	201913554	75ddd87b-7ae4-47f7-85ce-c1bc2837c3ee	f
e377cf40-dbc0-4b9b-8128-36fdde629624	201913554	67a2c734-18cc-47ce-9eb4-55093a66bb97	f
23eba3f2-897d-4124-b698-f055b8d77ab1	201913554	09f6b1ce-ccbb-4325-9d85-cc9a8a230359	f
06cd13b8-29e7-49a6-aab7-cbebe5c211dd	201913554	145d24d8-968f-46b1-9cbc-05b4fe5b26d7	f
e2f8b1aa-b825-4528-8d66-3cec83b6755f	201913554	afd01f0e-d322-482f-9f5a-cb2090fb401b	f
b0b8c9cd-bee8-4c4a-a35a-1c85a6d33cf4	201913554	b565b275-9273-43d2-97b0-09c0bc72cfac	f
aa8b3671-bc63-4743-921f-ce4dd40bc555	201913554	bfb8ac81-97ee-4c01-b411-2ed950063191	f
52769b4e-6a0d-42eb-9725-d7e0d8ee12fa	201913554	ca339628-175b-40b1-b3bd-d3ba82ff0035	f
9346d1c7-ce43-429b-a261-5eb2d15f677c	201913554	799417d3-38bb-4659-913b-49f5386a5d99	f
a771f27d-fcb5-41fd-8aaf-ad920417ae9e	201913554	61e70f5c-14b4-4fb0-83ab-6dd3aa57ee14	f
e1dd106d-fa0d-434f-a47e-0f495c882005	201913554	2d37ecce-a55f-495e-89ea-1e3b39377ff0	f
11e63ce2-b0b4-4922-975c-eda65bbf2c0e	201913554	5695f2c1-6d54-465d-8511-5da7f7a08704	f
e5854cb9-fb0b-48cd-a64d-0b6bbbefd4e3	201913554	472e3dcb-6eb9-472a-9703-dbd7349045a4	f
72c5526b-9f08-4ad0-9023-578232732652	201913554	fb24182c-d856-4fa8-a5c7-b443a60f9de9	f
f2cae2d6-92de-49c0-a8c4-0dba0323ca7a	201913554	b06d223e-d70e-4b27-9c47-e191455d0dd7	f
ae1a178f-0521-4fad-8582-6b76cb523e81	201913554	8ee269cc-e0ab-4d71-83eb-856d98a4b574	f
29578322-cbc1-4612-ac51-867936bcd600	201913554	6b0b31af-f585-4b50-821e-60e80d513e5d	f
01768a6f-a030-4394-9c14-dbc28334e38c	201913554	0ad4b146-375f-4992-a570-8a3edca2c25b	f
70d0552d-458c-403f-98c4-0c9b1a08243a	201913554	aae183c6-9a9d-42a0-a65f-54b2316796c8	f
01c69a8c-289a-4910-b2de-af05b574f693	201913554	c4ce6cad-9389-4d63-b822-e4d9955ae8d0	f
4144528d-e77a-43f4-8442-15cfe41f4a96	201913554	3a3c9690-7419-4243-834c-9ba3cb3e9fc5	f
1b2f0318-4f6a-44ec-a3ea-77f1051e3210	201913554	85049409-7367-4d96-aedf-3662b11b9144	f
0e5869cf-9021-4f57-aecf-e5948ac52ba8	201913554	386bb1bc-6b6e-42e9-8acb-5da6e7a33bdd	f
977b0217-c16c-42bc-b017-43a0f06ebd6c	201913554	c4435c95-605f-43e5-bac2-d980cc66ed5f	f
864ddc7b-0a9a-4a94-bd49-296ee7212cc2	201913554	562da940-6cb0-4ddc-be0f-fa79194e0a26	f
88507f02-741f-486d-be70-f762fa778738	201913554	4bea8bf7-e1c4-4c1b-9e93-2a92200b4516	f
c7db0c53-3db2-4660-a7bb-032d46425477	201913554	cefcc016-0878-46ed-9b9a-826da26bfbef	f
96a74505-c089-4947-8d07-ef08626ed6df	201913554	b0874ec2-bfea-4ecd-9daa-cff48da109ee	f
f3ca35f7-6a62-4253-92ff-ce5601433d72	201913554	e34cc120-1225-45e6-a2d0-66282fb8fc9a	f
f0272606-d9c2-4e1b-8f4b-550a1b553044	201913554	1a427ec0-0a46-4bdd-bb05-7f26664a3211	f
b17aaab2-cb3d-4ac2-8a3b-d9421e9b6d6a	201913554	e92e6849-9a2e-42b1-a877-af250b74f168	f
2dc1997f-aaf9-42ed-9345-c5e70f7d3447	201913554	5cd33cbd-8d97-4f28-ab42-04520576f814	f
cb56a437-df51-4107-9b00-a73e859252a6	201913554	ccd8eb11-f321-44cd-b5d2-e1c46bfafc18	f
12795ad2-ea2e-4461-b749-554fb2542d38	201913554	86a44d5f-3248-4403-8aa4-64ea86c467cd	f
7700b8a6-f4e5-4b45-97e8-145f744fa343	201913554	dd0f3812-9f60-4323-bb5b-440ad708da64	f
668bc35c-8d16-4195-aa25-4862ec6330a5	201913554	ed5c62e5-a4e5-46b1-9898-106e01207d3e	f
478dab35-3572-4cab-90cb-0cfd7767aa34	201913554	700e3081-26fc-424f-8c52-95192e9c3783	f
b60c4352-97d9-4168-a8da-04e47f7e95b3	201913554	ea55c61d-89a5-4bf9-ba63-3c125aae785b	f
0044958f-b116-464d-901a-8c46dc29a22d	202020609	513be2ac-52a0-4e7b-88eb-7995f931ae1d	f
13647b4c-2658-47ff-b35f-122bc1cf9496	202020609	4421f3c3-3636-420f-a41b-c5687cb258ce	f
6f27e2dc-c120-454c-ba10-6efceb3091ec	202020609	9d943ab7-f942-47eb-a5d9-7db4d137e0e3	f
0b177da3-6493-4a3f-b0c6-5e23c542d697	202020609	75ddd87b-7ae4-47f7-85ce-c1bc2837c3ee	f
28943e43-4c28-4c72-b425-169b296d7c1e	202020609	2b7820ed-6c8a-47f1-8236-7be65f379b97	f
0b023164-755c-43c4-909e-bf0a14806176	202020609	67a2c734-18cc-47ce-9eb4-55093a66bb97	f
375c9b7f-d543-48eb-8cd6-a777343e1cc3	202020609	09f6b1ce-ccbb-4325-9d85-cc9a8a230359	f
5cd97102-6ad3-4c7e-80ec-e2318ab58c78	202020609	145d24d8-968f-46b1-9cbc-05b4fe5b26d7	f
38213b27-6f38-48fb-a1c3-72d83e2f4b77	202020609	afd01f0e-d322-482f-9f5a-cb2090fb401b	f
0b5247b9-3f6b-4194-9960-5d070bee7f87	202020609	b565b275-9273-43d2-97b0-09c0bc72cfac	f
9562c117-cdfd-454a-9e35-2543278e5c40	202020609	bfb8ac81-97ee-4c01-b411-2ed950063191	f
d5935f22-6280-4908-9ccf-0ce3296b06df	202020609	ca339628-175b-40b1-b3bd-d3ba82ff0035	f
15f34012-f6cf-46cf-8942-12fc7c4368f6	202020609	799417d3-38bb-4659-913b-49f5386a5d99	f
d0f5fc55-5238-4ded-8e0a-4d826e97f632	202020609	61e70f5c-14b4-4fb0-83ab-6dd3aa57ee14	f
2719bd79-1c6e-410a-b51b-3fad3ce10f94	202020609	2d37ecce-a55f-495e-89ea-1e3b39377ff0	f
c44e3397-2bcd-4347-97e2-ffbe4f447e59	202020609	5695f2c1-6d54-465d-8511-5da7f7a08704	f
7591dd70-1acb-4502-b650-98ac351d7e63	202020609	472e3dcb-6eb9-472a-9703-dbd7349045a4	f
a32672c2-e7d5-4cc4-baae-3c2203325f8a	202020609	fb24182c-d856-4fa8-a5c7-b443a60f9de9	f
85903e47-82e4-4c43-9e95-689dc0cbc36b	202020609	b06d223e-d70e-4b27-9c47-e191455d0dd7	f
d1919167-0d4f-45c5-a956-54133d0baec6	202020609	8ee269cc-e0ab-4d71-83eb-856d98a4b574	f
ef241f02-522a-43f8-aee8-90862af2a375	202020609	6b0b31af-f585-4b50-821e-60e80d513e5d	f
72256efe-fdc3-43a5-b3ca-d9a5fd056855	202020609	0ad4b146-375f-4992-a570-8a3edca2c25b	f
bb0bfb34-b332-4da7-bda7-f8ca9470c2b0	202020609	aae183c6-9a9d-42a0-a65f-54b2316796c8	f
406cf25e-9737-46fc-a995-e345515bfb42	202020609	c4ce6cad-9389-4d63-b822-e4d9955ae8d0	f
8477dff4-8eeb-49da-be75-27a63d8d38c6	202020609	3a3c9690-7419-4243-834c-9ba3cb3e9fc5	f
288a7bac-db07-46de-b85f-aacfeaa8324c	202020609	85049409-7367-4d96-aedf-3662b11b9144	f
85ef3a1c-c7c4-4760-9af7-1bf38b5867d0	202020609	386bb1bc-6b6e-42e9-8acb-5da6e7a33bdd	f
36330d68-bb2e-4ac0-97c9-cd9eedac6b20	202020609	c4435c95-605f-43e5-bac2-d980cc66ed5f	f
346d8223-af39-4792-9222-764e3d7e142a	202020609	562da940-6cb0-4ddc-be0f-fa79194e0a26	f
fde89f5c-9748-401b-ba39-5c15ce92cf87	202020609	4bea8bf7-e1c4-4c1b-9e93-2a92200b4516	f
f3cfbfc8-bf02-446b-be07-05b22a6f53d4	202020609	cefcc016-0878-46ed-9b9a-826da26bfbef	f
749d5eb9-754e-4fe4-ac0b-61ead60311c4	202020609	b0874ec2-bfea-4ecd-9daa-cff48da109ee	f
9f9d7335-dc09-459a-b693-46da114929c8	202020609	1a427ec0-0a46-4bdd-bb05-7f26664a3211	f
2ea89a5e-adbf-4ecc-a725-1c83cb016c9d	202020609	e92e6849-9a2e-42b1-a877-af250b74f168	f
9226177d-e2f4-45e5-940a-d1dadbfe8b60	202020609	5cd33cbd-8d97-4f28-ab42-04520576f814	f
d8cce754-984e-46be-9d34-0127267e2a33	202020609	ccd8eb11-f321-44cd-b5d2-e1c46bfafc18	f
95aeb6cd-6a60-497c-bc05-ec64c974b52a	202020609	dd0f3812-9f60-4323-bb5b-440ad708da64	f
38087539-e65a-4127-8bbd-29674381adad	202020609	ed5c62e5-a4e5-46b1-9898-106e01207d3e	f
06e472da-1ed8-467b-a35e-0630a5280a36	202020609	330a2e3a-2b17-47fc-93e0-6a51d0aa3090	f
e39f6330-d67d-4c3c-b777-a09065ba8253	202020609	f91b8e99-db7b-4fd0-81c9-e77086e98cb9	f
a807396b-8e2b-46ec-8067-6bafb4decbb2	202020609	ea55c61d-89a5-4bf9-ba63-3c125aae785b	f
f5132cdb-529c-48a0-9629-8be4d7470574	202020609	26d14fe4-2626-480f-9d6f-4275d9bd2521	f
d5a54321-39b4-436f-af93-52215781a07c	202021525	09f6b1ce-ccbb-4325-9d85-cc9a8a230359	f
0523b74a-e3c2-42db-970f-42b44117f85d	202021525	145d24d8-968f-46b1-9cbc-05b4fe5b26d7	f
743dd893-8843-4eed-a77e-14b8e994d1d3	202021525	afd01f0e-d322-482f-9f5a-cb2090fb401b	f
1119a648-2d76-4d3e-aad6-dbcf273d1b96	202021525	bfb8ac81-97ee-4c01-b411-2ed950063191	f
158089e0-282c-46d0-9cdb-a138327c26fa	202021525	ca339628-175b-40b1-b3bd-d3ba82ff0035	f
82df8fff-98e4-4215-a5cf-d57348c3e925	202021525	799417d3-38bb-4659-913b-49f5386a5d99	f
e7ab878f-a6bb-4b8d-a0c0-9830d439eb96	202021525	61e70f5c-14b4-4fb0-83ab-6dd3aa57ee14	f
a08711dd-d038-4e0a-8396-357cc5fe352d	202021525	5695f2c1-6d54-465d-8511-5da7f7a08704	f
6b1e88a3-b21d-41fa-b931-842eef5e19f0	202021525	472e3dcb-6eb9-472a-9703-dbd7349045a4	f
eaf83e21-a2a3-4db2-bc3c-c804371b65fe	202021525	fb24182c-d856-4fa8-a5c7-b443a60f9de9	f
4773d371-bde0-453d-8d68-444d8aea452a	202021525	b06d223e-d70e-4b27-9c47-e191455d0dd7	f
61731497-ebd0-4726-8552-f461174736de	202021525	f55bf8c4-a42b-4f89-9103-29608ea41f38	f
1ac0add6-289d-4aff-9efe-4140ae38000f	202021525	6b0b31af-f585-4b50-821e-60e80d513e5d	f
186f5ad2-9bd4-4876-9fec-0c43d0eb54df	202021525	0ad4b146-375f-4992-a570-8a3edca2c25b	f
94d71885-7335-4601-80cd-c6f2b816cf14	202021525	aae183c6-9a9d-42a0-a65f-54b2316796c8	f
d9a65fe9-b82c-4282-8fa6-d61c252b2033	202021525	3a3c9690-7419-4243-834c-9ba3cb3e9fc5	f
08c417fb-16c2-4522-81b9-c0f979659548	202021525	386bb1bc-6b6e-42e9-8acb-5da6e7a33bdd	f
25abc20e-77d5-4dde-a229-a6fbe90b585c	202021525	562da940-6cb0-4ddc-be0f-fa79194e0a26	f
5739c584-4e42-4450-965d-a71e217fa0b7	202021525	cefcc016-0878-46ed-9b9a-826da26bfbef	f
c5df754d-800c-4bf8-adea-c5ffc81cdea4	202011140	85bf329f-3a7c-42c4-adcc-b3f0f537da82	f
35727474-6eed-4de8-98c6-50aebb22cc01	202011140	74f52914-c989-4e39-ba41-0993610fc0be	f
c2d90991-739e-454e-8c77-33d7f9da8194	202011140	8906056c-8041-47c8-b2d4-374dcfe3271f	f
0bfafaa7-4f92-4927-831e-55fb9cd3bb65	202011140	7e6e67c9-6c0b-422d-9954-aba4879808a2	f
90461131-2a04-45a1-ae68-4a2085f876b4	202011140	52153601-1201-4466-b468-0eec96b9a540	f
35e1025a-062e-4656-a949-77f97b5c5685	202011140	b565b275-9273-43d2-97b0-09c0bc72cfac	f
a1e1fb2b-8c47-44bf-bdba-79d709e10822	202011140	5b5f335b-20ae-42b9-97be-4f11877bb4ee	f
476d4355-cda1-4810-b325-53036ef1ea93	202011140	61e70f5c-14b4-4fb0-83ab-6dd3aa57ee14	f
fcbe8933-93d0-42fb-a962-67565c095359	202011140	c4ce6cad-9389-4d63-b822-e4d9955ae8d0	f
dd52c19b-18a9-4d5a-af5d-5476b0cfa588	202011140	8977ac57-8b75-40d0-b6cc-1ed2c3a3877c	f
ab42bab1-276e-41a9-8b36-f15909023726	202011140	85049409-7367-4d96-aedf-3662b11b9144	f
ff7e7d31-b130-4d9b-a79c-ac3012f3e6c5	202011140	c4435c95-605f-43e5-bac2-d980cc66ed5f	f
931e8954-b5bc-4abd-9c0a-9d9f707e2050	202011140	1e166445-213f-4f11-9997-dddfce1e5da5	f
b05ff201-3d66-4cc1-aa43-2ea8acbfbd5a	202011140	b0874ec2-bfea-4ecd-9daa-cff48da109ee	f
b2006348-c091-49f6-a6bb-ed5e7f97e7fa	202011140	7c36d931-88b6-4622-9ac9-b5d0f249656c	f
ba738b1a-b818-4213-aafb-8afc44f4f165	202011140	5cd33cbd-8d97-4f28-ab42-04520576f814	f
cd36f632-4335-4bf1-ac59-d01c4818e056	202011140	ccd8eb11-f321-44cd-b5d2-e1c46bfafc18	f
3bcf21db-6dd7-4f14-85fc-7b5cded9e4f5	202011140	330a2e3a-2b17-47fc-93e0-6a51d0aa3090	f
b0ead7b4-059e-47de-bc0e-21fe1cfc7d67	202011140	f91b8e99-db7b-4fd0-81c9-e77086e98cb9	f
f228d15b-ccd6-45db-b839-b82d73f5ea4c	201922019	85bf329f-3a7c-42c4-adcc-b3f0f537da82	f
f9c5735a-a098-440d-9349-c48e89b2f1dc	201922019	4225d780-483a-4dd2-8949-d15eef98bd46	f
2479044b-06e2-4e38-9bb3-50f97b7c496f	201922019	95d040c4-3645-40bc-aaf3-d62ce7463896	f
28ee08dd-d9ea-4fc5-9438-d80b10a761c2	201922019	cc8840e4-0a7a-467f-a0f9-5392cbf2e78d	f
4be6e12e-ec8f-446d-8b0b-16edc121cbcb	201922019	515a51fd-a0d9-4fc2-a616-c3e81b07d9ee	f
b07be75f-a5cb-4f7b-a7c0-038a531f4d3a	201922019	74f52914-c989-4e39-ba41-0993610fc0be	f
8b93f43c-2bb8-43e8-baba-652f9220e887	201922019	3fdb9fb0-11f4-454a-86a9-60790bb36807	f
721d29a2-4606-4b90-806c-50098d2914d5	201922019	95a27c59-b9b7-49be-943e-3e47ba5a0810	f
98044cf0-7746-43cd-93d5-51ff511fea0b	201922019	8906056c-8041-47c8-b2d4-374dcfe3271f	f
46816b6f-4a3d-4147-b0e9-e0834b2e7fa3	201922019	513be2ac-52a0-4e7b-88eb-7995f931ae1d	f
5b572679-dfdc-462a-80ed-dba97c67a0f6	201922019	9d943ab7-f942-47eb-a5d9-7db4d137e0e3	f
e40df89c-522a-4672-b968-c0a0a1cd9d22	201922019	7e6e67c9-6c0b-422d-9954-aba4879808a2	f
3ddbd577-65f3-41f3-96db-456ade65a93d	201922019	67a2c734-18cc-47ce-9eb4-55093a66bb97	f
23b545fa-ca40-46b6-bcb7-17d5016546fc	201922019	b565b275-9273-43d2-97b0-09c0bc72cfac	f
4030ac56-1fe6-4f00-bd0f-3f32c375d4c1	201922019	ca339628-175b-40b1-b3bd-d3ba82ff0035	f
049b0c4e-e0a2-46b5-97d4-4abda8200f35	201922019	61e70f5c-14b4-4fb0-83ab-6dd3aa57ee14	f
1f5611df-2808-4f90-95a9-6de9e34f4ade	201922019	8977ac57-8b75-40d0-b6cc-1ed2c3a3877c	f
da76bfef-e524-42c3-b9df-5f007e1e6d1b	201922019	85049409-7367-4d96-aedf-3662b11b9144	f
8aaf6ea0-cf77-49b9-9afc-cc29d48e92b0	201922019	1e166445-213f-4f11-9997-dddfce1e5da5	f
ebaf338a-93aa-4807-8400-2837cda09d8b	201922019	562da940-6cb0-4ddc-be0f-fa79194e0a26	f
5c932ee1-3eae-4e26-8f84-073c3907a08a	201922019	b0874ec2-bfea-4ecd-9daa-cff48da109ee	f
b9a8b3de-1e4c-4da2-9bf4-e6b3180cab7d	201922019	7c36d931-88b6-4622-9ac9-b5d0f249656c	f
e19328c9-3d0e-4850-848a-d3451f2d1af9	201922019	e34cc120-1225-45e6-a2d0-66282fb8fc9a	f
527d265c-1b65-4792-82a5-8b083f5e7495	201922019	5cd33cbd-8d97-4f28-ab42-04520576f814	f
3edaffb2-d660-4683-a331-05cffdb7e788	201922019	ccd8eb11-f321-44cd-b5d2-e1c46bfafc18	f
9ddac9fa-c2e6-4d4e-be63-e98c0e7da957	201922019	86a44d5f-3248-4403-8aa4-64ea86c467cd	f
0413aabb-1b17-406c-b74f-80641d8941f6	201922019	330a2e3a-2b17-47fc-93e0-6a51d0aa3090	f
c26634a9-71a6-4e12-8a8d-7f6195fddf02	201922019	f91b8e99-db7b-4fd0-81c9-e77086e98cb9	f
3c89bff6-b0fa-4881-bd88-eecd8caaaac9	201922019	700e3081-26fc-424f-8c52-95192e9c3783	f
eeafcd7b-acd9-46e8-89ad-c35bd6799290	202112020	85bf329f-3a7c-42c4-adcc-b3f0f537da82	f
5544b441-e81c-4744-84c9-90fe2810adc2	202112020	4225d780-483a-4dd2-8949-d15eef98bd46	f
bb2aa150-2407-4aed-a2d0-b850674dd0b7	202112020	3fdb9fb0-11f4-454a-86a9-60790bb36807	f
0e60851d-cfcc-4077-808e-82791a54b60f	202112020	513be2ac-52a0-4e7b-88eb-7995f931ae1d	f
29f948e9-ba7c-46c1-b413-ea8747304c3c	202112020	75ddd87b-7ae4-47f7-85ce-c1bc2837c3ee	f
36ba3c3d-172a-45e7-a849-8e93e79cd271	202112020	09f6b1ce-ccbb-4325-9d85-cc9a8a230359	f
4c220812-effa-4242-83af-8138eae41869	202112020	bfb8ac81-97ee-4c01-b411-2ed950063191	f
c93ce1fb-db6e-4c92-bd0c-e70c4825fec8	202112020	5695f2c1-6d54-465d-8511-5da7f7a08704	f
d015aec6-3d36-4aa0-9fcd-f2e1306e6d6d	202112020	fb24182c-d856-4fa8-a5c7-b443a60f9de9	f
1df67a71-452b-462b-92a4-124ae43999c0	202112020	f55bf8c4-a42b-4f89-9103-29608ea41f38	f
5c4be457-0557-4b33-adab-1b2e03485f22	202112020	6b0b31af-f585-4b50-821e-60e80d513e5d	f
99744fc6-0471-4830-a996-4bbaae70f775	202112020	8977ac57-8b75-40d0-b6cc-1ed2c3a3877c	f
3ebbc1d7-2876-4122-8951-f9fb416b4f9b	202112020	3a3c9690-7419-4243-834c-9ba3cb3e9fc5	f
1ee05fb7-3168-495a-b4ad-788426ddba98	202112020	c4435c95-605f-43e5-bac2-d980cc66ed5f	f
d177f2d3-e994-42ef-b601-775d34c8d23a	202112020	562da940-6cb0-4ddc-be0f-fa79194e0a26	f
2e60f1fb-6933-42d2-acac-fe905946ba49	202112020	b0874ec2-bfea-4ecd-9daa-cff48da109ee	f
bfda89bf-beb6-40db-8430-51b35a0d67b0	202112020	e34cc120-1225-45e6-a2d0-66282fb8fc9a	f
a9634181-a43b-4289-999d-a176d1d46eef	202112020	e92e6849-9a2e-42b1-a877-af250b74f168	f
04455c1e-72be-4985-b8aa-20c36437146b	202112020	5cd33cbd-8d97-4f28-ab42-04520576f814	f
4da6529d-9b52-4e68-a581-8af44e0e5e7f	202112020	86a44d5f-3248-4403-8aa4-64ea86c467cd	f
f627266d-a4b7-451e-9fb1-c6c8ea9e82c0	202112020	ed5c62e5-a4e5-46b1-9898-106e01207d3e	f
c3dfaa87-f79f-4ca7-9008-ba5966e43ce5	202112020	330a2e3a-2b17-47fc-93e0-6a51d0aa3090	f
df630851-4f43-45b8-8a54-dde9565eda0f	202112020	700e3081-26fc-424f-8c52-95192e9c3783	f
2e0edfe3-0270-4304-b4e2-4db535522816	202112020	26d14fe4-2626-480f-9d6f-4275d9bd2521	f
5b1b1a2f-fe8c-42fe-a705-1f4082d53487	202021113	85bf329f-3a7c-42c4-adcc-b3f0f537da82	f
ddb5ed69-3988-4e44-9b02-01a1ce2bce1e	202021113	95d040c4-3645-40bc-aaf3-d62ce7463896	f
75d25a92-36a7-416d-8f3d-441cea85cc16	202021113	cc8840e4-0a7a-467f-a0f9-5392cbf2e78d	f
a35fba01-ed4f-4b0a-a1c8-f09d9b7b7ca2	202021113	515a51fd-a0d9-4fc2-a616-c3e81b07d9ee	f
e28146f2-4ff1-4899-92d2-1e017ede766b	202021113	74f52914-c989-4e39-ba41-0993610fc0be	f
23c28233-d5f4-4e0a-b124-3e711b531b84	202021113	3fdb9fb0-11f4-454a-86a9-60790bb36807	f
e45121fb-1583-44d1-a124-d78c5f7d1528	202021113	917606b1-2373-49a0-8865-bc358b1f220e	f
2e102cd2-8bda-4b9c-bca3-0688fc4b2dd4	202021113	95a27c59-b9b7-49be-943e-3e47ba5a0810	f
a0e4afc8-6ef3-4144-912b-b37ed0a7244b	202021113	6579a993-aa63-4f62-86f1-d95331bd5c55	f
682b8223-d0cb-43ab-b2c3-d6ce3998af27	202021113	9d943ab7-f942-47eb-a5d9-7db4d137e0e3	f
85272acf-6d3f-4cf2-bdb5-6c6b43ece89d	202021113	e9822fc2-ddc2-41a5-8abe-17f073ab1229	f
1e5ea85a-5873-4ef8-98b0-73dd70c0f970	202021113	67a2c734-18cc-47ce-9eb4-55093a66bb97	f
d7d71982-4d13-41f3-9ee1-0b3d259df4fd	202021113	875fb7ed-55fd-4a73-830c-104de61ceff9	f
226710e2-4560-4eff-97e1-fb4608a4c301	202021113	52153601-1201-4466-b468-0eec96b9a540	f
d517c415-bfe2-44ce-b42a-0dbaf164e071	202021113	09f6b1ce-ccbb-4325-9d85-cc9a8a230359	f
a4f7651a-cbb9-4bbb-9ba2-68cc257cd64b	202021113	5b5f335b-20ae-42b9-97be-4f11877bb4ee	f
3034a4ff-44bf-416f-b30f-3796c358d613	202021113	8ee269cc-e0ab-4d71-83eb-856d98a4b574	f
d5949175-4bed-4e1e-901b-31d4343c2edc	202021113	562da940-6cb0-4ddc-be0f-fa79194e0a26	f
6fe8d07d-bec1-4fe4-b098-30ed0d6ae63c	202021113	e92e6849-9a2e-42b1-a877-af250b74f168	f
\.


--
-- Data for Name: assistants; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.assistants (code, login, first_names, last_names, nickname) FROM stdin;
202021525	f.melo	Federico	Melo Barrero	Fede
202021113	d.fuquen	David Alejandro	Fuquen Florez	Dave
202112020	s.martinezn	Santiago	Martinez Novoa	Santi
202011140	m.ruizg	Mariana	Ruiz Giraldo	Maru
201922019	n.carvajalc	Nicolas	Carvajal Chaves	Nico
202020609	g.ardila	Gabriel Eduardo	Ardila Carrillo	Ardilla
201913554	am.ochoat	Andres Martin	Ochoa Toro	Andres
\.


--
-- Data for Name: scheduled_slots; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.scheduled_slots (schedule_id, assistant_availability_id, is_remote) FROM stdin;
\.


--
-- Data for Name: schedules; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.schedules (id, name, is_official) FROM stdin;
\.


--
-- Data for Name: time_slots; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.time_slots (id, start_hour, end_hour, day) FROM stdin;
85bf329f-3a7c-42c4-adcc-b3f0f537da82	800	900	MONDAY
74f52914-c989-4e39-ba41-0993610fc0be	900	930	MONDAY
8906056c-8041-47c8-b2d4-374dcfe3271f	930	1030	MONDAY
7e6e67c9-6c0b-422d-9954-aba4879808a2	1030	1100	MONDAY
52153601-1201-4466-b468-0eec96b9a540	1100	1200	MONDAY
5b5f335b-20ae-42b9-97be-4f11877bb4ee	1200	1230	MONDAY
2d37ecce-a55f-495e-89ea-1e3b39377ff0	1230	1330	MONDAY
8ee269cc-e0ab-4d71-83eb-856d98a4b574	1330	1400	MONDAY
c4ce6cad-9389-4d63-b822-e4d9955ae8d0	1400	1500	MONDAY
c4435c95-605f-43e5-bac2-d980cc66ed5f	1500	1530	MONDAY
b0874ec2-bfea-4ecd-9daa-cff48da109ee	1530	1630	MONDAY
5cd33cbd-8d97-4f28-ab42-04520576f814	1630	1700	MONDAY
330a2e3a-2b17-47fc-93e0-6a51d0aa3090	1700	1800	MONDAY
4225d780-483a-4dd2-8949-d15eef98bd46	800	900	TUESDAY
3fdb9fb0-11f4-454a-86a9-60790bb36807	900	930	TUESDAY
513be2ac-52a0-4e7b-88eb-7995f931ae1d	930	1030	TUESDAY
75ddd87b-7ae4-47f7-85ce-c1bc2837c3ee	1030	1100	TUESDAY
09f6b1ce-ccbb-4325-9d85-cc9a8a230359	1100	1200	TUESDAY
bfb8ac81-97ee-4c01-b411-2ed950063191	1200	1230	TUESDAY
5695f2c1-6d54-465d-8511-5da7f7a08704	1230	1330	TUESDAY
f55bf8c4-a42b-4f89-9103-29608ea41f38	1330	1400	TUESDAY
8977ac57-8b75-40d0-b6cc-1ed2c3a3877c	1400	1500	TUESDAY
1e166445-213f-4f11-9997-dddfce1e5da5	1500	1530	TUESDAY
7c36d931-88b6-4622-9ac9-b5d0f249656c	1530	1630	TUESDAY
ccd8eb11-f321-44cd-b5d2-e1c46bfafc18	1630	1700	TUESDAY
f91b8e99-db7b-4fd0-81c9-e77086e98cb9	1700	1800	TUESDAY
95d040c4-3645-40bc-aaf3-d62ce7463896	800	900	WEDNESDAY
917606b1-2373-49a0-8865-bc358b1f220e	900	930	WEDNESDAY
4421f3c3-3636-420f-a41b-c5687cb258ce	930	1030	WEDNESDAY
2b7820ed-6c8a-47f1-8236-7be65f379b97	1030	1100	WEDNESDAY
145d24d8-968f-46b1-9cbc-05b4fe5b26d7	1100	1200	WEDNESDAY
ca339628-175b-40b1-b3bd-d3ba82ff0035	1200	1230	WEDNESDAY
472e3dcb-6eb9-472a-9703-dbd7349045a4	1230	1330	WEDNESDAY
6b0b31af-f585-4b50-821e-60e80d513e5d	1330	1400	WEDNESDAY
3a3c9690-7419-4243-834c-9ba3cb3e9fc5	1400	1500	WEDNESDAY
562da940-6cb0-4ddc-be0f-fa79194e0a26	1500	1530	WEDNESDAY
e34cc120-1225-45e6-a2d0-66282fb8fc9a	1530	1630	WEDNESDAY
86a44d5f-3248-4403-8aa4-64ea86c467cd	1630	1700	WEDNESDAY
700e3081-26fc-424f-8c52-95192e9c3783	1700	1800	WEDNESDAY
cc8840e4-0a7a-467f-a0f9-5392cbf2e78d	800	900	THURSDAY
95a27c59-b9b7-49be-943e-3e47ba5a0810	900	930	THURSDAY
9d943ab7-f942-47eb-a5d9-7db4d137e0e3	930	1030	THURSDAY
67a2c734-18cc-47ce-9eb4-55093a66bb97	1030	1100	THURSDAY
afd01f0e-d322-482f-9f5a-cb2090fb401b	1100	1200	THURSDAY
799417d3-38bb-4659-913b-49f5386a5d99	1200	1230	THURSDAY
fb24182c-d856-4fa8-a5c7-b443a60f9de9	1230	1330	THURSDAY
0ad4b146-375f-4992-a570-8a3edca2c25b	1330	1400	THURSDAY
85049409-7367-4d96-aedf-3662b11b9144	1400	1500	THURSDAY
4bea8bf7-e1c4-4c1b-9e93-2a92200b4516	1500	1530	THURSDAY
1a427ec0-0a46-4bdd-bb05-7f26664a3211	1530	1630	THURSDAY
dd0f3812-9f60-4323-bb5b-440ad708da64	1630	1700	THURSDAY
ea55c61d-89a5-4bf9-ba63-3c125aae785b	1700	1800	THURSDAY
515a51fd-a0d9-4fc2-a616-c3e81b07d9ee	800	900	FRIDAY
6579a993-aa63-4f62-86f1-d95331bd5c55	900	930	FRIDAY
e9822fc2-ddc2-41a5-8abe-17f073ab1229	930	1030	FRIDAY
875fb7ed-55fd-4a73-830c-104de61ceff9	1030	1100	FRIDAY
b565b275-9273-43d2-97b0-09c0bc72cfac	1100	1200	FRIDAY
61e70f5c-14b4-4fb0-83ab-6dd3aa57ee14	1200	1230	FRIDAY
b06d223e-d70e-4b27-9c47-e191455d0dd7	1230	1330	FRIDAY
aae183c6-9a9d-42a0-a65f-54b2316796c8	1330	1400	FRIDAY
386bb1bc-6b6e-42e9-8acb-5da6e7a33bdd	1400	1500	FRIDAY
cefcc016-0878-46ed-9b9a-826da26bfbef	1500	1530	FRIDAY
e92e6849-9a2e-42b1-a877-af250b74f168	1530	1630	FRIDAY
ed5c62e5-a4e5-46b1-9898-106e01207d3e	1630	1700	FRIDAY
26d14fe4-2626-480f-9d6f-4275d9bd2521	1700	1800	FRIDAY
38032d04-4257-4b85-94f3-952d09742629	800	900	SATURDAY
bdefcc9e-4cc2-4c2e-8c43-d3b2013f2379	900	930	SATURDAY
9f89008f-36c7-4745-aaf3-bdee019fff40	930	1030	SATURDAY
8fb6540d-8e8d-4ff8-b413-a43dd7408bcd	1030	1100	SATURDAY
69aa91c1-1e34-4296-adc5-1f3c8f0961bd	1100	1200	SATURDAY
58bbbcaf-fb6c-4f26-9fee-7e93cff26ce1	1200	1230	SATURDAY
69bfb434-1c20-4411-b437-794c7c9ef2e5	1230	1330	SATURDAY
3ae914b3-9500-45c8-b642-fc6e568bf1d1	1330	1400	SATURDAY
4f07e411-f142-4de1-8b1b-f1de1f523524	1400	1500	SATURDAY
f75a8ed1-7285-4029-b4b2-b2b586817675	1500	1530	SATURDAY
ca86cc8e-2a49-48b2-b99f-b6f99578453d	1530	1630	SATURDAY
c7704524-43f6-4e00-85ef-d94216d18999	1630	1700	SATURDAY
cfd12402-5ba2-4c48-8667-874eb7454496	1700	1800	SATURDAY
85baed55-bdf0-4b33-b99b-860f8829fdc5	800	900	SUNDAY
62a33891-fbe5-4db5-a1ea-6b0ee65bce8c	900	930	SUNDAY
81e11f3f-a41d-495c-8bc6-cb0c262ac243	930	1030	SUNDAY
01a95441-34fd-45a0-affa-2fc5d5fcad3d	1030	1100	SUNDAY
ca5f1073-4bde-4b06-8a7b-cd034e44c4e9	1100	1200	SUNDAY
380c8815-4724-4dc5-889c-ea7c2b977bef	1200	1230	SUNDAY
44f244fd-0b57-4d66-9ecb-79622ff6430e	1230	1330	SUNDAY
b4408955-d860-4816-83c0-b2a59ae07c10	1330	1400	SUNDAY
b8880314-3247-4db4-9e58-271ddea45133	1400	1500	SUNDAY
310151f2-c253-413f-bf1f-695df4477568	1500	1530	SUNDAY
1721b6d7-f73e-4a48-acdd-ccce61fb3c3d	1530	1630	SUNDAY
4e671487-c069-4cfa-b468-92a940188c64	1630	1700	SUNDAY
d30bf5b5-30af-4809-8871-e5310a49490d	1700	1800	SUNDAY
\.


--
-- Name: assistants_code_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.assistants_code_seq', 1, false);


--
-- Name: assistant_availabilities assistant_availabilities_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.assistant_availabilities
    ADD CONSTRAINT assistant_availabilities_pkey PRIMARY KEY (id);


--
-- Name: assistants assistants_login_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.assistants
    ADD CONSTRAINT assistants_login_key UNIQUE (login);


--
-- Name: assistants assistants_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.assistants
    ADD CONSTRAINT assistants_pkey PRIMARY KEY (code);


--
-- Name: scheduled_slots scheduled_slots_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.scheduled_slots
    ADD CONSTRAINT scheduled_slots_pkey PRIMARY KEY (schedule_id, assistant_availability_id);


--
-- Name: schedules schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedules
    ADD CONSTRAINT schedules_pkey PRIMARY KEY (id);


--
-- Name: time_slots time_slots_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.time_slots
    ADD CONSTRAINT time_slots_pkey PRIMARY KEY (id);


--
-- Name: assistant_availabilities assistant_availabilities_assistant_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.assistant_availabilities
    ADD CONSTRAINT assistant_availabilities_assistant_code_fkey FOREIGN KEY (assistant_code) REFERENCES public.assistants(code);


--
-- Name: assistant_availabilities assistant_availabilities_time_slot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.assistant_availabilities
    ADD CONSTRAINT assistant_availabilities_time_slot_id_fkey FOREIGN KEY (time_slot_id) REFERENCES public.time_slots(id);


--
-- Name: scheduled_slots scheduled_slots_assistant_availability_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.scheduled_slots
    ADD CONSTRAINT scheduled_slots_assistant_availability_id_fkey FOREIGN KEY (assistant_availability_id) REFERENCES public.assistant_availabilities(id);


--
-- Name: scheduled_slots scheduled_slots_schedule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.scheduled_slots
    ADD CONSTRAINT scheduled_slots_schedule_id_fkey FOREIGN KEY (schedule_id) REFERENCES public.schedules(id);


--
-- PostgreSQL database dump complete
--

